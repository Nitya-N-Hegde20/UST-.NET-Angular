import { Component } from '@angular/core';

@Component({
  selector: 'app-child-a',
  standalone: true,
  imports: [],
  templateUrl: './child-a.component.html',
  styleUrl: './child-a.component.css'
})
export class ChildAComponent {

}
