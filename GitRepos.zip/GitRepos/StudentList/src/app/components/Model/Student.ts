export class Students {

    RollNumber: number;
  
    Name: string;
  
    Branch: string;
  
    Sem: number;
  
    
  
  }